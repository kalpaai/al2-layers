import os

BINARIES_PATHS = [
    os.path.join(os.path.join(LOADER_DIR, '../../'), 'lib64')
] + BINARIES_PATHS
